/* -*- Mode: C; c-basic-offset:4 ; indent-tabs-mode:nil ; -*- */
/*
 * See COPYRIGHT in top-level directory.
 */

#ifndef COMMON_H
#define COMMON_H

#define DEFAULT_PORT    60439
#define SEND_BUF_LEN    20
#define RECV_BUF_LEN    20

#endif /* COMMON_H */

